#MEANAuthApp

The full code will be on Github when it is done.

This is the code from video number 3

#Usage

- Install Dependencies
npm install

- Run Server
npm start OR nodemon